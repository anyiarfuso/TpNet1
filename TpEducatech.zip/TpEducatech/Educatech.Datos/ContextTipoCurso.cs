﻿using Educatech.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Datos
{
    public class ContextTipoCurso : Context
    {
        private readonly Context _context;

        public ContextTipoCurso()
        {
            _context = new Context();
        }

        public void AgregarTipoCurso(TipoCurso tipoCurso)
        {
            _context.Certificados.Add(tipoCurso);
            _context.SaveChanges();
        }

        public List<TipoCurso> ListarTiposCurso()
        {
            return _context.TiposCurso.ToList();
        }

        public TipoCurso BuscarTipoCurso(int id)
        {
            return _context.TiposCurso.Find(id);
        }

        public void ModificarTipoCurso(TipoCurso tipoCurso)
        {
            _context.TiposCurso.Update(tipoCurso);
            _context.SaveChanges();
        }

        public void EliminarTipoCurso(int id)
        {
            var tipoCurso = _context.TiposCurso.Find(id);
            _context.TiposCurso.Remove(tipoCurso);
            _context.SaveChanges();
        }
    }
}
