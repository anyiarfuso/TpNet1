﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Educatech.Dominio;

namespace Educatech.Datos
{
    public class ContextAlumno : Context
    {
        private readonly Context _context;

        public ContextAlumno()
        {
            _context = new Context();
        }

        public void AgregarAlumno(Alumno alumno)
        {
            _context.Alumnos.Add(alumno);
            _context.SaveChanges();
        }

        public List<Alumno> ListarAlumnos()
        {
            return _context.Alumnos.ToList();
        }

        public Alumno BuscarAlumno(int id)
        {
            return _context.Alumnos.Find(id);
        }

        public void ModificarAlumno(Alumno alumno)
        {
            _context.Alumnos.Update(alumno);
            _context.SaveChanges();
        }

        public void EliminarAlumno(int id)
        {
            var alumno = _context.Alumnos.Find(id);
            _context.Alumnos.Remove(alumno);
            _context.SaveChanges();
        }
    }
}
