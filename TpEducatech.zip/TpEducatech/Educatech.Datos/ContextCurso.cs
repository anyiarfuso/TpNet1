﻿using Educatech.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Educatech.Dominio;

namespace Educatech.Datos
{
    public class ContextCurso : Context
    {
        private readonly Context _context;

        public ContextCurso()
        {
            _context = new Context();
        }

        public void AgregarCurso(Curso curso)
        {
            _context.Cursos.Add(curso);
            _context.SaveChanges();
        }

        public List<Curso> ListarCursos()
        {
            return _context.Cursos.ToList();
        }

        public Curso BuscarCurso(int id)
        {
            return _context.Cursos.Find(id);
        }

        public void ModificarCurso(Curso curso)
        {
            _context.Cursos.Update(curso);
            _context.SaveChanges();
        }

        public void EliminarCurso(int id)
        {
            var curso = _context.Cursos.Find(id);
            _context.Cursos.Remove(curso);
            _context.SaveChanges();
        }
    }
}
