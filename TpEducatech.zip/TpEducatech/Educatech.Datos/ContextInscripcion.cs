﻿using Educatech.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Datos
{
    public class ContextInscripcion : Context
    {
        private readonly Context _context;

        public ContextInscripcion()
        {
            _context = new Context();
        }

        public void AgregarInscripcion(Inscripcion inscripcion)
        {
            _context.Inscripciones.Add(inscripcion);
            _context.SaveChanges();
        }

        public List<Inscripcion> ListarInscripciones()
        {
            return _context.Inscripciones.ToList();
        }

        public Inscripcion BuscarInscripcion(int id)
        {
            return _context.Inscripciones.Find(id);
        }

        public void ModificarInscripcion(Inscripcion inscripcion)
        {
            _context.Inscripciones.Update(inscripcion);
            _context.SaveChanges();
        }

        public void EliminarInscripcion(int id)
        {
            var inscripcion = _context.Inscripciones.Find(id);
            _context.Inscripciones.Remove(inscripcion);
            _context.SaveChanges();
        }




    }
}
