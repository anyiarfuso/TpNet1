﻿using Microsoft.EntityFrameworkCore;
using Educatech.Dominio;
using System.Collections.Generic;
namespace Educatech.Datos
{
    public class Context : DbContext
    {

        public DbSet<Alumno> Alumnos { get; set; }
        public DbSet<Profesor> Profesores { get; set; }
        public DbSet<Curso> Cursos { get; set; }
        public DbSet<Inscripcion> Inscripciones { get; set; }
        public DbSet<Certificado> Certificados { get; set; }
        public DbSet<TipoCurso> TiposCurso { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=localhost\MSSQLSERVER02;Initial Catalog=Educatech;Integrated Security=True;TrustServerCertificate=True;");
        }
        //string connectionString = "Server=localhost;Database=Educatech;Trusted_Connection=True;";

        public Context()
        {
            this.Database.EnsureCreated();
        }


    }
}