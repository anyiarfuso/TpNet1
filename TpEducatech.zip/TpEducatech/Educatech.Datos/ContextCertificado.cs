﻿using Educatech.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Datos
{
    public class ContextCertificado : Context
    {
        private readonly Context _context;

        public ContextCertificado()
        {
            _context = new Context();
        }

        public void AgregarCertificado(Certificado certificado)
        {
            _context.Certificados.Add(certificado);
            _context.SaveChanges();
        }

        public List<Certificado> ListarCertificados()
        {
            return _context.Certificados.ToList();
        }

        public Certificado BuscarCertificado(int id)
        {
            return _context.Certificados.Find(id);
        }

        public void ModificarCertificado(Certificado certificado)
        {
            _context.Certificados.Update(certificado);
            _context.SaveChanges();
        }

        public void EliminarCertificado(int id)
        {
            var certificado = _context.Certificados.Find(id);
            _context.Certificados.Remove(certificado);
            _context.SaveChanges();
        }




    }
}
