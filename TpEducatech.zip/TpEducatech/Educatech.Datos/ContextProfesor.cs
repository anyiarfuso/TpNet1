﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Educatech.Dominio;

namespace Educatech.Datos
{
    public class ContextProfesor : Context
    {
        private readonly Context _context;

        public ContextProfesor()
        {
            _context = new Context();
        }

        public void AgregarProfesor(Profesor profesor)
        {
            _context.Profesores.Add(profesor);
            _context.SaveChanges();
        }

        public List<Profesor> ListarProfesores()
        {
            return _context.Profesores.ToList();
        }

        public Profesor BuscarProfesor(int id)
        {
            return _context.Profesores.Find(id);
        }

        public void ModificarProfesor(Profesor profesor)
        {
            _context.Profesores.Update(profesor);
            _context.SaveChanges();
        }

        public void EliminarProfesor(int id)
        {
            var profesor = _context.Profesores.Find(id);
            _context.Profesores.Remove(profesor);
            _context.SaveChanges();
        }
    }
}
