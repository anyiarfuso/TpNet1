﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Dominio
{
    public class Inscripcion
    {
        private int id;
        private DateTime fechaInscripcion;
        private string cancelado;

        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public DateTime FechaInscripcion
        {
            get { return fechaInscripcion; }
            set { fechaInscripcion = value; }

        }

        public string Cancelado
        {
            get { return cancelado; }
            set { cancelado = value; }

        }
        public Certificado Certificado { get; set; }
        //relacion con alumno n..1
        public int AlumnoId { get; set; }
        public Alumno Alumno { get; set; }
        // por que defino un id y tmb el objeto

        // Relación con Curso (N:1)
        public int CursoId { get; set; }
        public Curso Curso { get; set; }

        public Inscripcion() { }

        public Inscripcion(int id, string cancelado, DateTime fechaInscripcion, int alumnoId, int cursoId)
        {
            Id = id;
            FechaInscripcion = fechaInscripcion;
            Cancelado = cancelado;
            AlumnoId = alumnoId;
            CursoId = cursoId;
        }
    }
}
