﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Educatech.Dominio
{
    public class Curso
    {
        private int id, duracion;

        private string descripcion, nombre;

        private DateTime fechaInicio, fechaFin;

        private TimeSpan horaInicio, horaFin;

        private string[] dias;

        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public int Duracion
        {
            get { return id; }
            set { id = value; }

        }
        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }

        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }

        }

        public DateTime FechaInicio
        {
            get { return fechaInicio; }
            set { fechaInicio = value; }

        }
        public DateTime FechaFin
        {
            get { return fechaFin; }
            set { fechaFin = value; }

        }
        public TimeSpan HoraInicio
        {
            get { return horaInicio; }
            set { horaInicio = value; }

        }
        public TimeSpan HoraFin
        {
            get { return horaFin; }
            set { horaFin = value; }

        }

        public string[] Dias
        {
            get { return dias; }
            set { dias = value; }
        }
        public int ProfesorId { get; set; }
        public Profesor Profesor { get; set; }

        // Relación con Inscripcion (1:N)
        public List<Inscripcion> Inscripciones { get; set; } = new List<Inscripcion>();
        public Curso() { }

        public Curso(int id, int duracion, string descripcion,string nombre, DateTime fechaInicio, DateTime fechaFin, TimeSpan horaInicio, TimeSpan horaFin, string[] dias, int profesorId)
        {
            Id = id;
            Duracion = duracion;
            Descripcion = descripcion;
            Nombre = nombre;
            FechaInicio = fechaInicio;
            FechaFin = fechaFin;
            HoraFin = horaFin;
            HoraInicio = horaInicio;
            Dias = dias;
            ProfesorId = profesorId;

        }
    }

}
