﻿using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;

namespace Educatech.Dominio
{
    public class Alumno
    {
        private int id;

        private string nombreCompleto, mail, clave, telefono;

        List<Inscripcion> Inscripciones { get; set; } = new List<Inscripcion>();

        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public string Telefono
        {
            get { return telefono; }
            set { telefono = value; }

        }

        public string NombreCompleto
        {
            get { return nombreCompleto; }
            set { nombreCompleto = value; }

        }

        public string Mail
        {
            get { return mail; }
            set { mail = value; }

        }
        public string Clave
        {
            get { return clave; }
            set { clave = value; }

        }

        public Alumno(){}

        public Alumno(int id, string nombreCompleto, string mail, string clave, string telefono)
        {
            Id = id;
            NombreCompleto = nombreCompleto;
            Mail = mail;
            Clave = clave;
            Telefono = telefono;
        }
    }



}
