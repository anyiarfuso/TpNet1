﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Dominio
{
    public class TipoCurso
    {
        private int id;

        private string descripcion;

        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        public ICollection<Curso> Cursos { get; set; } = new List<Curso>();

        public TipoCurso() { }

        public TipoCurso(int id, string descripcion)
        {
            Id = id;
            Descripcion = descripcion;
        }

    }
}
