﻿using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;

namespace Educatech.Dominio
{
    public class Certificado
    {
        private int id;

        private string descripcion;

        private DateTime fechaEmision;




        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }

        }

        public DateTime FechaEmision
        {
            get { return fechaEmision; }
            set { fechaEmision = value; }

        }
        public int InscripcionId { get; set; } // Este campo es obligatorio
        public Inscripcion Inscripcion { get; set; }

        public Certificado() { }

        public Certificado(int id, string descripcion, DateTime fechaEmision)
        {
            Id = id;
            Descripcion = descripcion;
            FechaEmision = fechaEmision;
        }
    }



}