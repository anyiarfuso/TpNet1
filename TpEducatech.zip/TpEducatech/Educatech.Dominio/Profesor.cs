﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Educatech.Dominio
{
    public class Profesor
    {
        private int id;

        private string nombreCompleto, mail, clave, telefono, especialidad;



        [Key]
        public int Id
        {
            get { return id; }
            set { id = value; }

        }
        public string Telefono
        {
            get { return telefono; }
            set { telefono = value; }

        }

        public string Especialidad
        {
            get { return especialidad; }
            set { especialidad = value; }

        }
        public string NombreCompleto
        {
            get { return nombreCompleto; }
            set { nombreCompleto = value; }

        }

        public string Mail
        {
            get { return mail; }
            set { mail = value; }

        }
        public string Clave
        {
            get { return clave; }
            set { clave = value; }

        }
        public List<Curso> Cursos { get; set; } = new List<Curso>();

        public Profesor() { }

        public Profesor(int id, string nombreCompleto, string mail, string clave, string telefono, string especialidad)
        {
            Id = id;
            NombreCompleto = nombreCompleto;
            Mail = mail;
            Clave = clave;
            Telefono = telefono;
            Especialidad = especialidad;
        }
    }
}
